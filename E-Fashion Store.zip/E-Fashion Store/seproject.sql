-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 19, 2023 at 10:24 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `seproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `colors` varchar(255) DEFAULT NULL,
  `sizes` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `category`, `colors`, `sizes`, `name`, `brand`, `image`, `price`) VALUES
(1, 'Shoes', 'Grey', 'S', 'Classic Runner Shoes', 'Adidas', 'Shoes1.jpg', 2199.00),
(2, 'Dresses', 'Black,Red', 'XS', 'Floral Print Maxi Dress', 'Glamourous', 'Dress1.jpg', 2199.00),
(3, 'Dresses', 'Pink', 'XS', 'Floral Print Maxi Dress', 'The Secret Label', 'Dress2.jpg', 4499.00),
(4, 'Dresses', 'Black', 'XS', 'originals long tree Dress', 'Adidas', 'Dress3.jpg', 20999.00),
(5, 'Shoes', 'White', '10', 'Roma', 'Puma', 'Shoes4.jpg', 4999.00),
(7, 'Shoes', 'Grey', 'M', 'Classic Runner Shoes', 'Adidas', 'Shoes1.jpg', 2399.00),
(8, 'Shoes', 'Grey', 'L', 'Classic Runner Shoes', 'Adidas', 'Shoes1.jpg', 2999.00),
(9, 'Dresses', 'Black', 'S', 'Floral Print Maxi Dress', 'Glamourous', 'Dress1.jpg', 2299.00),
(10, 'Dresses', 'Red', 'M', 'Floral Print Maxi Dress', 'Glamourous', 'Dress1.jpg', 2399.00),
(11, 'Dresses', 'Red', 'L', 'Floral Print Maxi Dress', 'Glamourous', 'Dress1.jpg', 2499.00),
(12, 'Dresses', 'Black', 'XL', 'Floral Print Maxi Dress', 'Glamourous', 'Dress1.jpg', 2799.00),
(13, 'Dresses', 'Pink', 'M', 'Floral Print Maxi Dress', 'The Secret Label', 'Dress2.jpg', 4699.00),
(14, 'Dresses', 'Pink', 'L', 'Floral Print Maxi Dress', 'The Secret Label', 'Dress2.jpg', 4899.00),
(15, 'Dresses', 'Black', 'S', 'originals long tree Dress', 'Adidas', 'Dress3.jpg', 22999.00),
(16, 'Dresses', 'Black', 'L', 'originals long tree Dress', 'Adidas', 'Dress3.jpg', 24999.00),
(17, 'Shoes', 'White', '8', 'Roma', 'Puma', 'Shoes4.jpg', 4499.00),
(18, 'Shoes', 'White', '9', 'Roma', 'Puma', 'Shoes4.jpg', 4799.00),
(19, 'Shoes', 'White', '10', 'Reebok Zig Dynamica 4 Shoes', 'Reebok', 'Shoes5.jpeg', 5999.00),
(20, 'Shoes', 'White', '7', 'Reebok Zig Dynamica 4 Shoes', 'Reebok', 'Shoes5.jpeg', 5499.00),
(6, 'Shoes', 'White', '9', 'Reebok Zig Dynamica 4 Shoes', 'Reebok', 'Shoes5.jpeg', 5599.00),
(21, 'Shoes', 'Black', '9', 'Nike Youth Court Borough', 'Nike', 'Shoes2.jpeg', 5599.00),
(22, 'Shoes', 'Black', '10', 'Nike Youth Court Borough', 'Nike', 'Shoes2.jpeg', 6199.00),
(23, 'Tshirt', 'Black', 'M', 'Nike Youth Club', 'Nike', 'Tshirt1.jpeg', 1599.00),
(24, 'Tshirt', 'Black', 'M', 'Puma Slid Classic', 'Puma', 'Tshirt2.jpeg', 2599.00),
(25, 'Shirt', 'White', 'XL', 'Peter Classic', 'Peter England', 'Shirt2.jpg', 2599.00),
(26, 'Shirt', 'Green', 'XL', 'Peter Classic', 'Peter England', 'Shirt7.jpg', 2799.00),
(27, 'Shirt', 'Green', 'M', 'Party Classic', 'Peter England', 'Shirt6.jpg', 2599.00),
(28, 'Pants', 'Green', 'XL', 'Jaipur Kurti Olive Green Cotton Pants', 'Jaipur Kurti', 'Pant3.jpeg', 2299.00),
(29, 'Shirt', 'Pink', 'L', 'Men Cotton Shirt', 'Peter England', 'Shirt2.jpg', 2999.00),
(30, 'Pants', 'Blue', 'XL', 'Men Blue Pant', 'Peter England', 'Pant2.jpeg', 5299.00),
(30, 'Pants', 'Black', 'XL', 'Men Black Pant', 'Peter England', 'Pant1.jpeg', 5499.00),
(31, 'Shoes', 'Red', '10', 'SOFTRIDE Enzo Nxt Men Running Shoes ', 'Puma', 'Shoes6.jpg', 3599.00),
(32, 'Tshirt', 'Black', 'L', 'Nike Icon Block T-Shirt ', 'Nike', 'Tshirt5.jpeg', 5599.00),
(33, 'Tshirt', 'Pink', 'L', 'Organic T-Shirt - bright pink ', 'Earth Positive', 'Tshirt4.jpeg', 3599.00),
(34, 'Tshirt', 'Blue', 'XL', 'Adidas Icon Block T-Shirt ', 'Adidas', 'Tshirt3.jpeg', 5599.00),
(36, 'Shirt', 'White', 'S', 'Organic Shirt - White ', 'Earth Positive', 'shirt2.jpg', 1599.00),
(35, 'Tshirt', 'Red', 'S', 'Reebok UFC Mens Red Fan Gear Official Logo T-Shirt  ', 'Reebok', 'Tshirt6.jpg', 4599.00);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
