<?php

// fetch_data.php

include('database_connection.php');

if (isset($_POST["action"])) {
  $query = "SELECT * FROM products WHERE 1";

  if (isset($_POST["minimum_price"], $_POST["maximum_price"]) && !empty($_POST["minimum_price"]) && !empty($_POST["maximum_price"])) {
    $query .= " AND price BETWEEN :minimum_price AND :maximum_price";
  }
  if (isset($_POST["category"])) {
    $category_filter = implode("','", $_POST["category"]);
    $query .= " AND category IN('" . $category_filter . "')";
  }
  if (isset($_POST["brand"])) {
    $brand_filter = implode("','", $_POST["brand"]);
    $query .= " AND brand IN('" . $brand_filter . "')";
  }
  if (isset($_POST["sizes"])) {
    $sizes_filter = implode("','", $_POST["sizes"]);
    $query .= " AND sizes IN('" . $sizes_filter . "')";
  }
  if (isset($_POST["colors"])) {
    $colors_filter = implode("','", $_POST["colors"]);
    $query .= " AND colors IN('" . $colors_filter . "')";
  }

  $statement = $connect->prepare($query);

if (isset($_POST["minimum_price"], $_POST["maximum_price"]) && !empty($_POST["minimum_price"]) && !empty($_POST["maximum_price"])) {
  $statement->bindValue(':minimum_price', $_POST["minimum_price"]);
  $statement->bindValue(':maximum_price', $_POST["maximum_price"]);
}

$statement->execute();

  $result = $statement->fetchAll();
  $total_row = $statement->rowCount();
  $output = '';

  if ($total_row > 0) {
    foreach ($result as $row) {
      $output .= '
      <div class="col-sm-4 col-lg-3 col-md-3">
        <div style="border:1px solid #ccc; border-radius:5px; padding:16px; margin-bottom:16px; height:450px;">
          <img src="image/' . $row['image'] . '" alt="" class="img-responsive" style="width:100%; height:100;" >
          <p align="center"><strong><a href="#">' . $row['name'] . '</a></strong></p>
          <h4 style="text-align:center;" class="text-danger">' . $row['price'] . '</h4>
          <p>Category: ' . $row['category'] . ' <br />
          Brand: ' . $row['brand'] . ' <br />
          Sizes: ' . $row['sizes'] . ' <br />
          Color: ' . $row['colors'] . ' </p>
        </div>
      </div>
      ';
    }
  } else {
    $output = '<h3>No Data Found</h3>';
  }

  echo $output;
}

?>
